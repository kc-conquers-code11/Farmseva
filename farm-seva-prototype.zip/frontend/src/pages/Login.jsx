import React, {useState} from 'react';
import api from '../services/api';

export default function Login(){
  const [email, setEmail] = useState('farmer1@demo.com');
  const [password, setPassword] = useState('password');

  const login = async () => {
    try {
      const r = await api.post('/auth/login', { email, password });
      localStorage.setItem('fs_token', r.data.token);
      localStorage.setItem('fs_user', JSON.stringify(r.data.user));
      window.location.href = '/dashboard';
    } catch (e) {
      alert(e.response?.data?.error || 'Login failed');
    }
  };

  const register = async () => {
    try {
      const r = await api.post('/auth/register', { email, password, name: email.split('@')[0] });
      localStorage.setItem('fs_token', r.data.token);
      localStorage.setItem('fs_user', JSON.stringify(r.data.user));
      window.location.href = '/dashboard';
    } catch (e) {
      alert(e.response?.data?.error || 'Register failed');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white rounded shadow">
      <h1 className="text-2xl mb-4">Farm-Seva — Login</h1>
      <input className="border p-2 w-full mb-2" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="border p-2 w-full mb-2" value={password} onChange={e=>setPassword(e.target.value)} />
      <div className="flex">
        <button className="btn" onClick={login}>Login</button>
        <button className="btn ml-2" onClick={register}>Register</button>
      </div>
    </div>
  );
}
