import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './index.css'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Marketplace from './pages/Marketplace'
import Advisory from './pages/Advisory'
import Weather from './pages/Weather'
import Schemes from './pages/Schemes'

function App(){
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login/>} />
        <Route path='/dashboard' element={<Dashboard/>} />
        <Route path='/marketplace' element={<Marketplace/>} />
        <Route path='/advisory' element={<Advisory/>} />
        <Route path='/weather' element={<Weather/>} />
        <Route path='/schemes' element={<Schemes/>} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App />)
