const express = require('express');
const router = express.Router();
const { Low } = require('lowdb');
const FileSync = require('lowdb/node');
const path = require('path');

const file = path.join(__dirname, '..', 'db.json');
const adapter = new FileSync.default(file);
const db = new Low(adapter);

router.get('/', async (req, res) => {
  await db.read();
  res.json(db.data.schemes || []);
});

module.exports = router;
